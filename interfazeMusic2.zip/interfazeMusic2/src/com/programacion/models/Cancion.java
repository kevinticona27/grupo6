package com.programacion.models;

import java.sql.Date;

public class Cancion {
    private int idCancion;
    private String nombreCancion;
    private int albumIdAlbum;
    private int albumArtistaIdArtista;
    private Date fechaLanzamiento;

    // Getters y Setters
}
