package com.programacion.models;

import java.sql.Date;

public class Artista {
    private int idArtista;
    private String nombre;
    private String seudonimo;
    private String nacionalidad;
    private Date fechaNacimiento;

    // Getters y Setters
}