package com.programacion.models;

public class ListaDeReproduccion {
    private int idLista;
    private int usuarioIdUsuario;
    private String nombreLista;

    // Getters y Setters
}
