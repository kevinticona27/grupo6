package com.programacion.models;

import java.util.Date;

public class Album {
    private int idAlbum;
    private int artistaIdArtista;
    private String nombreAlbum;
    private Date fechaLanzamiento;

    // Getters y Setters
}
