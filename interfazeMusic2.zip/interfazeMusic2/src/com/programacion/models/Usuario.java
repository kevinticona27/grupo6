package com.programacion.models;

import java.sql.Date;

import javax.xml.crypto.Data;

public class Usuario {
    private int idUsuario;
    private String nombre;
    private String correoElectronico;
    private Date fechaCreacion;

    // Getters y Setters
}
